# Apni Dunia — موبائل سے APK بنانے کا آسان طریقہ

یہ project GitHub Actions کے ذریعے cloud میں APK build کرنے کے لیے تیار کیا گیا ہے۔

1. GitHub پر نیا repository بنائیں۔
2. اس project کی تمام files upload کریں۔
3. GitHub میں **Actions** کھولیں۔
4. **Build Apni Dunia APK** منتخب کریں۔
5. **Run workflow** دبائیں۔
6. Build مکمل ہونے کے بعد **Artifacts** میں `Apni-Dunia-debug-apk` ڈاؤن لوڈ کریں۔

نوٹ: یہ debug APK ہے۔ Google Play Store کے لیے بعد میں signed release/AAB بنانا ہوگا۔
